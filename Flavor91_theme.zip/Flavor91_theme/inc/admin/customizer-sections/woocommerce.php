<?php
$url = TP_THEME_URI . 'images/admin/layout/';
$woocommerce = $titan->createThimCustomizerSection( array(
	'name'     => 'WooCommerce',
	'position' => 5,
 	'id'       => 'woocommerce',
) );